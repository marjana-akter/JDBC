package io.mtech.dbUtil;

//import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import java.sql.Connection;
import java.sql.DriverManager;


import java.sql.SQLException;
import java.util.logging.Logger;

import io.naztech.JavaPractise.doa.impl.CrudDaoImplement;


public class DBConn{
public static void main(String[] args) throws ClassNotFoundException{
	Logger log= Logger.getLogger(DBConn.class.getName());
	  CrudDaoImplement cdi = new CrudDaoImplement();
    	  cdi.createTable();
		   //cdi.insertData();
			 // cdi.deleteData();
			  //cdi.update();
		   //cdi.alterTable();
		   //cdi.readTable();
	            
}
}


