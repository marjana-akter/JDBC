package io.naztech.JavaPractise.doa.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;
import java.sql.Statement;
import io.mtech.dbUtil.DBConn;

public class CrudDaoImplement {
	
	

	public void createTable() throws ClassNotFoundException {
		// TODO Auto-generated method stub
		Logger log = Logger.getLogger(DBConn.class.getName());
		String connectionUrl = "jdbc:sqlserver://vNTDACWSSQLD002:1433;databaseName=DEV_TEST; user=dev_test_dbo;password=dev_test_dbo123";
		Connection con=null;
		 String myTableName ="CREATE TABLE POST_Type(postType_ID int PRIMARY KEY not null identity(1,1) ,Qualification varchar(20),Experience_year int )"; 
         
		
		try {
			//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			 con = DriverManager.getConnection(connectionUrl);
			log.info("successful");
			Statement statement = con.createStatement();
		
			statement.executeUpdate(myTableName);
			System.out.println("Table Created");
		}
		// Handle any errors that may have occurred.
		catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
        
		
	}
	public void insertData() {
		Logger log = Logger.getLogger(DBConn.class.getName());
		String connectionUrl = "jdbc:sqlserver://vNTDACWSSQLD002:1433;databaseName=DEV_TEST; user=dev_test_dbo;password=dev_test_dbo123";
		Connection con=null;
		
		String insertData = "INSERT INTO persons VALUES (?,?,?,?,?)";
		try {
			//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			 con = DriverManager.getConnection(connectionUrl);
			log.info("successful");
			PreparedStatement stmt=con.prepareStatement(insertData);
			stmt.setInt(1,2);
			stmt.setString(2,"tihsa");
			stmt.setString(3,"marzan");
			stmt.setString(4,"Mirpur");
			stmt.setString(5,"Dhaka");
			stmt.executeUpdate();
			System.out.println("Data Inserted");
		}
		// Handle any errors that may have occurred.
		catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	public void deleteData() {
		Logger log = Logger.getLogger(DBConn.class.getName());
		String connectionUrl = "jdbc:sqlserver://vNTDACWSSQLD002:1433;databaseName=DEV_TEST; user=dev_test_dbo;password=dev_test_dbo123";
		Connection con=null;
		String deleteData = "delete from Persons where Lastname=(?)";
		
		try {
			//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			 con = DriverManager.getConnection(connectionUrl);
			log.info("successful");
			PreparedStatement statement = con.prepareStatement(deleteData);
			statement.setString(1,"tihsa");
		
			statement.executeUpdate();
			System.out.println("Data deleted");
		}
		// Handle any errors that may have occurred.
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void update() {
		Logger log = Logger.getLogger(DBConn.class.getName());
		String connectionUrl = "jdbc:sqlserver://vNTDACWSSQLD002:1433;databaseName=DEV_TEST; user=dev_test_dbo;password=dev_test_dbo123";
		Connection con=null;
		String updt = "update Persons set LastName='tisha' where LastName='shova' ";
		try {
			//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			 con = DriverManager.getConnection(connectionUrl);
			log.info("successful");
			Statement statement = con.createStatement();
		
			statement.executeUpdate(updt);
			System.out.println("Data updated");
		}
		// Handle any errors that may have occurred.
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void alterTable() {
		Logger log = Logger.getLogger(DBConn.class.getName());
		String connectionUrl = "jdbc:sqlserver://vNTDACWSSQLD002:1433;databaseName=DEV_TEST; user=dev_test_dbo;password=dev_test_dbo123";
		Connection con=null;
		String alt = "";
		try {
			//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			 con = DriverManager.getConnection(connectionUrl);
			log.info("successful");
			Statement statement = con.createStatement();
		
			statement.executeUpdate(alt);
			System.out.println("Table Changed");
		}
		// Handle any errors that may have occurred.
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void readTable() {
		Logger log = Logger.getLogger(DBConn.class.getName());
		String cnnectionUrl = "jdbc:sqlserver://vNTDACWSSQLD002:1433;databaseName=DEV_TEST; user = dev_test_dbo; password = dev_test_dbo123";
		Connection con;
		String rd = "select * from POST";
		
		try {
			
			con = DriverManager.getConnection(cnnectionUrl);
			log.info("successfull");
			Statement statement = con.createStatement();
			
			ResultSet rs = statement.executeQuery(rd);
			while(rs.next()) {
				System.out.print("["+rs.getInt("postID"));
				System.out.print(" "+rs.getString("postType")+"");
				System.out.print(" "+rs.getString("Salary"));
				System.out.print(" "+rs.getInt("Room_no"));
				System.out.println(" "+rs.getString("Name")+"]");
			}
			
			
		}catch(SQLException e){
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	public void tableDrop() {
		Logger log = Logger.getLogger(DBConn.class.getName());
		String connectionUrl = "jdbc:sqlserver://vNTDACWSSQLD002:1433;databaseName=DEV_TEST; user=dev_test_dbo;password=dev_test_dbo123";
		Connection con=null;
		String drp = "";
	}
	
	 

}
